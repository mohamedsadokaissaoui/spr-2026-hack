<div align="center">

# SPR 2026 · Mammography Report Classification

**Reading Portuguese mammography reports and predicting their BI-RADS category (0–6)**

🏅 **4th place** · 💶 **€3,000 prize** · [Kaggle competition](https://www.kaggle.com/competitions/spr-2026-mammography-report-classification)

![Qwen](https://img.shields.io/badge/Qwen2.5%20%C2%B7%20Qwen3-14B-6c8ef5?style=flat-square)
![LoRA](https://img.shields.io/badge/LoRA-PEFT-2d333b?style=flat-square)
![4-bit](https://img.shields.io/badge/inference-4--bit%20NF4-2d333b?style=flat-square)
![Hardware](https://img.shields.io/badge/inference-2%C3%97%20T4-2d333b?style=flat-square)

</div>

---

## Overview

The final submission is a **logit-space ensemble of three fine-tuned 14B LLMs**, all running in 4-bit on two 16 GB T4 GPUs:

| | model | method | how the class is read |
|---|---|---|---|
| **A** | Qwen2.5-14B-Instruct + LoRA | Deep Mutual Learning (with B) | last hidden state → linear head (7 classes) |
| **B** | Qwen3-14B + LoRA | Deep Mutual Learning (with A) | last hidden state → linear head (7 classes) |
| **C** | Qwen3-14B + LoRA, 3 folds | SALSA | logits of the tokens `0`–`6` at the answer slot |

Each model's 7 logits are **z-scored per sample** (the heads and the LM logits live on different scales), then blended with weights **A 0.35 · B 0.40 · C 0.25** and argmax'd.

<p align="center"><img src="assets/birads_3d.png" width="60%" alt="3D UMAP of the training reports"><br>
<em>training reports embedded in 3D (TF-IDF + UMAP), coloured by BI-RADS</em></p>

## 1 · Deep Mutual Learning (models A + B)

Two students with different backbones train **together**: each one learns from the labels and from its peer's predicted distribution.

```
L_A = CE(z_A, y) + λ · KL(p_B ‖ p_A)
L_B = CE(z_B, y) + λ · KL(p_A ‖ p_B)        λ = 1
```

<p align="center"><img src="assets/dml.png" width="85%" alt="Deep mutual learning"></p>

- 4-bit NF4 backbones, LoRA `r=8, α=16` on all linear layers
- classifier head on the **last token's hidden state**
- class-weighted cross-entropy, oversampling of BI-RADS 5 (×2) and 6 (×3)
- 3 epochs, effective batch 8, lr 2e-4 with cosine schedule, early stopping on macro-F1
- both models trained sequentially on one H100 80 GB

## 2 · SALSA (model C)

[SALSA](https://arxiv.org/abs/2510.22691) classifies in **a single forward pass**: the prompt ends at `<BIRADS>`, and the model's next-token logits are read **only on the 7 digit tokens**, so there's no decoding loop and no answer parsing.

<p align="center"><img src="assets/salsa_vs_generation.png" width="100%" alt="Generation vs SALSA"></p>

- prompt written as a **4-step radiologist checklist** (complete exam? any finding? benign or suspicious? final check), in Portuguese
- **regex-detected hints** added to the prompt: follow-up language → class 3, "no prior exams" ≠ class 0, completed additional views ≠ class 0
- **GCE / Tsallis loss** (`q = 0.955`) on the answer-slot logits only, with class weights (more robust to noisy labels than plain CE)
- LoRA `r=16, α=32` on the attention and MLP projections
- 3 stratified folds, 6 epochs with early stopping; the 3 fold adapters are averaged at inference

## Data

- the competition training set, cleaned
- plus **only the rare classes (BI-RADS 4, 5, 6)** from an external report set, to fight the class imbalance
- 85 / 15 stratified split for DML, 3-fold stratified CV for SALSA

The data isn't included here; it belongs to the competition.

## Repository

```
src/
  train_dml.py               DML training, Qwen2.5-14B + Qwen3-14B (single H100)
  train_salsa.py             SALSA training, 3 folds
notebooks/
  inference_ensemble.ipynb   final submission: A + B + C on 2× T4, z-score ensemble
assets/                      figures
```

## Run

```bash
pip install -r requirements.txt
python src/train_dml.py      # writes backbone_{a,b}_best/ and head_{a,b}_best.pt
python src/train_salsa.py    # writes backbone_fold_{0,1,2}_best/
```

Then point the paths in section 3 of `notebooks/inference_ensemble.ipynb` to your checkpoints and run it on Kaggle (2× T4).
The scripts use Kaggle input paths; change them to run elsewhere.

## References

- Zhang et al., *Deep Mutual Learning*, CVPR 2018: [arXiv:1706.00384](https://arxiv.org/abs/1706.00384)
- *SALSA: single-pass autoregressive LLM structured classification*: [arXiv:2510.22691](https://arxiv.org/abs/2510.22691)
